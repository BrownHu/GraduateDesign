package com.example.qrcode.qrcode;

/**
 * Created by xum19 on 2017/10/18.
 */

public class API {

    public static String SCAN = "SCAN";

    public static String D_SCAN = "D_SCAN";

    public static String NEWCODE = "NEWCODE";

    public static String D_NEWCODE = "D_NEWCODE";

}
