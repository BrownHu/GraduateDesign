package com.example.qrcode.qrcode;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.uuzuche.lib_zxing.activity.CodeUtils;

import java.io.InputStream;
import java.security.PublicKey;

/**
 * 根据填写的信息生成二维码
 * Created by xum19 on 2017/10/18.
 */

public class NewQRActivity extends Activity {

    private EditText  sName, sAddress, sPhone, jName, jAddress, jPhone;//6个编辑框

    private ImageView newQR;//二维码

    private Button qrBtn;//生成按钮

    private Bitmap bitmap;

    String afterencrypt;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_generate);

        initView();


    }

    /**
     * 获取控件
     */
    private void initView(){
        sName = (EditText) findViewById(R.id.et_sname);
        sAddress = (EditText) findViewById(R.id.et_saddress);
        sPhone = (EditText) findViewById(R.id.et_sphone);
        jName = (EditText) findViewById(R.id.et_jname);
        jAddress = (EditText) findViewById(R.id.et_jaddress);
        jPhone = (EditText) findViewById(R.id.et_jphone);
        newQR = (ImageView) findViewById(R.id.pic);
        qrBtn = (Button) findViewById(R.id.qrbtn);

        qrBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s_name = sName.getText().toString().trim();
                String s_address = sAddress.getText().toString().trim();
                String s_Phone = sPhone.getText().toString().trim();
                String j_name = jName.getText().toString().trim();
                String j_address = jAddress.getText().toString().trim();
                String j_phone = jPhone.getText().toString().trim();

                String contents = "\n收货人姓名："  + s_name
                        + "\n收货人地址：" + s_address + "\n收货人电话：" + s_Phone
                        + "\n寄货人姓名：" + j_name + "\n寄货人地址：" + j_address + "\n寄货人电话：" + j_phone;
                if (TextUtils.isEmpty(contents)) {
                    Toast.makeText(NewQRActivity.this, "您的输入为空!", Toast.LENGTH_SHORT).show();
                    return;
                }

                try
                {

                    String source = contents.toString().trim();
                    // 从文件中得到公钥
                    InputStream inPublic = getAssets().open("pub.pem");
                    PublicKey publicKey = RSAUtils.loadPublicKey(inPublic);
                    // 加密
                    byte[] encryptByte = RSAUtils.encryptByPublicKeyForSpilt( source.getBytes(), publicKey.getEncoded());

                    // 为了方便观察吧加密后的数据用base64加密转一下，要不然看起来是乱码,所以解密是也是要用Base64先转换
                    afterencrypt = Base64Utils.encode(encryptByte);

                } catch (Exception e)
                {
                    e.printStackTrace();
                }

                bitmap = CodeUtils.createImage(afterencrypt, 120, 120, null);
                newQR.setImageBitmap(bitmap);
            }
        });
    }


}
