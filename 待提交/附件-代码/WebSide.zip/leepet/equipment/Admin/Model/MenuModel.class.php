<?php
//+---------------------------------
//| E8网络工作室 http:www.e8net.cn
//+---------------------------------
//| 后台菜单模型 <数据层>
//+---------------------------------
//| Author: webdd <2014/8/27>
//+---------------------------------

namespace Admin\Model;
use Think\Model;

class MenuModel extends Model{



}