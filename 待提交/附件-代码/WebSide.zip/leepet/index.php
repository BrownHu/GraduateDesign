<?php 
define('APP_NAME','equipment');
define('APP_PATH', './equipment/');
define('APP_DEBUG',TRUE);
define('BIND_MODULE', 'Home');
require "./ThinkPHP/ThinkPHP.php";
 ?>